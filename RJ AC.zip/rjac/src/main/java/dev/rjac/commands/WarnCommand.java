package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class WarnCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public WarnCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.warn")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 1) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjwarn <player> [reason]")); return true; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cPlayer not found.")); return true; }
        String reason = args.length > 1 ? String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)) : "Warned by staff";
        target.sendMessage(plugin.tag() + RJ_AC.color("&eYou have been warned: &f" + reason));
        plugin.getAlertManager().sendAlert(target, "ManualWarn", 0);
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aWarned &e" + target.getName() + "&7: &f" + reason));
        return true;
    }
}
