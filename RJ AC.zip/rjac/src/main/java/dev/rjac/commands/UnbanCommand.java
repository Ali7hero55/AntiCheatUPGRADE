package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.command.*;

public class UnbanCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public UnbanCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.ban")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 1) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjunban <player>")); return true; }
        plugin.getPunishmentManager().unban(args[0]);
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aUnbanned &e" + args[0] + "&7."));
        return true;
    }
}
