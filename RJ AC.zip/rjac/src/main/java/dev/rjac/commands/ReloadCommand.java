package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.command.*;

public class ReloadCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public ReloadCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.reload")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        plugin.reloadConfig();
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aConfig reloaded."));
        return true;
    }
}
