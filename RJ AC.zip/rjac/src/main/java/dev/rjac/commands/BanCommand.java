package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class BanCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public BanCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.ban")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 2) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjban <player> <duration> [reason]")); return true; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cPlayer not found.")); return true; }
        String duration = args[1];
        String reason = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "Banned by staff";
        plugin.getPunishmentManager().ban(target, reason, duration);
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aBanned &e" + target.getName() + " &7for &f" + duration + "&7."));
        return true;
    }
}
