package dev.rjac.commands;

import dev.rjac.RJ_AC;
import dev.rjac.gui.SuspiciousGUI;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class GuiCommand implements CommandExecutor {
    private final RJ_AC plugin;
    private final SuspiciousGUI gui;
    public GuiCommand(RJ_AC plugin) { this.plugin = plugin; this.gui = new SuspiciousGUI(plugin); }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
        if (!player.hasPermission("rjac.gui")) { player.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        gui.open(player);
        return true;
    }
}
