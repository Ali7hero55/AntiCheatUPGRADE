package dev.rjac.commands;

import dev.rjac.RJ_AC;
import dev.rjac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class CheckCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public CheckCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.check")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 1) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjcheck <player>")); return true; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cPlayer not found.")); return true; }
        PlayerData data = plugin.getPlayerDataManager().get(target);
        sender.sendMessage(plugin.tag() + RJ_AC.color("&eViolations for &b" + target.getName() + "&7:"));
        if (data.getAllViolations().isEmpty()) {
            sender.sendMessage(plugin.tag() + RJ_AC.color("&aNone."));
        } else {
            data.getAllViolations().entrySet().stream()
                    .sorted((a, b) -> b.getValue() - a.getValue())
                    .forEach(e -> sender.sendMessage(ChatColor.GOLD + "  " + e.getKey() + ": " + ChatColor.WHITE + e.getValue()));
        }
        return true;
    }
}
