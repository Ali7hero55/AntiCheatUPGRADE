package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class MuteCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public MuteCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.mute")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 2) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjmute <player> <duration> [reason]")); return true; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cPlayer not found.")); return true; }
        String duration = args[1];
        String reason = args.length > 2 ? String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length)) : "Muted by staff";
        plugin.getMuteManager().mute(target, duration, reason);
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aMuted &e" + target.getName() + " &7for &f" + duration + "&7."));
        return true;
    }
}
