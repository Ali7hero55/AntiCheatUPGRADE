package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class AlertsCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public AlertsCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Players only."); return true; }
        if (!player.hasPermission("rjac.alerts")) { player.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        plugin.getAlertManager().toggleAlerts(player);
        return true;
    }
}
