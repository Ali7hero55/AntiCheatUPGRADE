package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.command.*;

public class InfoCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public InfoCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        sender.sendMessage(plugin.tag() + RJ_AC.color(" &7v" + plugin.getDescription().getVersion() + " &8| &7by &bRJ_79"));
        sender.sendMessage(RJ_AC.color("  &7Checks: &e" + countChecks() + " &7| &7ProtocolLib packet detection enabled"));
        return true;
    }
    private int countChecks() {
        return 29; // 10 combat + 5 crystal + 9 movement + 5 misc
    }
}
