package dev.rjac.commands;

import dev.rjac.RJ_AC;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class UnmuteCommand implements CommandExecutor {
    private final RJ_AC plugin;
    public UnmuteCommand(RJ_AC plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("rjac.mute")) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cNo permission.")); return true; }
        if (args.length < 1) { sender.sendMessage(plugin.tag() + RJ_AC.color("&7Usage: &e/rjunmute <player>")); return true; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { sender.sendMessage(plugin.tag() + RJ_AC.color("&cPlayer not found.")); return true; }
        plugin.getMuteManager().unmute(target.getUniqueId());
        sender.sendMessage(plugin.tag() + RJ_AC.color("&aUnmuted &e" + target.getName() + "&7."));
        return true;
    }
}
