package dev.rjac.listeners;

import dev.rjac.RJ_AC;
import dev.rjac.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerItemHeldEvent;

public class InventoryListener implements Listener {

    private final RJ_AC plugin;
    public InventoryListener(RJ_AC plugin) { this.plugin = plugin; }

    @EventHandler
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;
        plugin.getPlayerDataManager().get(player).setInventoryOpen(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;
        plugin.getPlayerDataManager().get(player).setInventoryOpen(false);
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        Player player = e.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        // Track totem slot switch timing for AutoTotem
        if (player.getInventory().getItem(e.getNewSlot()) != null
                && player.getInventory().getItem(e.getNewSlot()).getType() == org.bukkit.Material.TOTEM_OF_UNDYING) {
            data.setLastTotemEquipTime(System.currentTimeMillis());
        }
    }

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = e.getView().getTitle();
        if (title.contains("Suspicious Players")) {
            e.setCancelled(true);
            if (e.getCurrentItem() == null) return;
            // Staff can click to run /rjcheck on that player
            String name = org.bukkit.ChatColor.stripColor(e.getCurrentItem().getItemMeta().getDisplayName())
                    .replace(" ⚠ TOTEM", "").trim();
            player.sendMessage(plugin.tag() + RJ_AC.color("&7Click: &e/rjcheck " + name));
        }
    }
}
