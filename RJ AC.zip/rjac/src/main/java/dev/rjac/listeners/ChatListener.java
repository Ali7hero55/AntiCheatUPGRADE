package dev.rjac.listeners;

import dev.rjac.RJ_AC;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {

    private final RJ_AC plugin;
    public ChatListener(RJ_AC plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent e) {
        Player player = e.getPlayer();
        if (plugin.getMuteManager().isMuted(player)) {
            e.setCancelled(true);
            player.sendMessage(plugin.tag() + RJ_AC.color(
                    plugin.getConfig().getString("punishments.mute-message", "&cYou are muted. Reason: &f{reason}")
                            .replace("{reason}", plugin.getMuteManager().getReason(player.getUniqueId()))));
        }
    }
}
