package dev.rjac.gui;

import dev.rjac.RJ_AC;
import dev.rjac.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;
import java.util.stream.Collectors;

public class SuspiciousGUI {

    private final RJ_AC plugin;

    public SuspiciousGUI(RJ_AC plugin) { this.plugin = plugin; }

    public void open(Player staff) {
        List<PlayerData> suspects = plugin.getPlayerDataManager().getAll().stream()
                .filter(d -> d.getTotalViolations() > 0)
                .sorted(Comparator.comparingInt(PlayerData::getTotalViolations).reversed())
                .collect(Collectors.toList());

        int size = Math.max(9, Math.min(54, ((suspects.size() / 9) + 1) * 9));
        Inventory inv = Bukkit.createInventory(null, size,
                RJ_AC.color(plugin.getPrefix() + " &7» &bSuspicious Players"));

        for (PlayerData data : suspects) {
            Player target = Bukkit.getPlayer(data.getUuid());
            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) skull.getItemMeta();

            boolean totemAbuser = data.getViolations("autototem") > 0;
            String displayName = totemAbuser
                    ? ChatColor.RED + "" + ChatColor.BOLD + data.getName() + " ⚠ TOTEM"
                    : ChatColor.YELLOW + data.getName();
            meta.setDisplayName(displayName);

            if (target != null) meta.setOwningPlayer(target);

            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.GRAY + "Total VL: " + ChatColor.RED + data.getTotalViolations());
            lore.add("");
            data.getAllViolations().entrySet().stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .forEach(e -> lore.add(ChatColor.GOLD + e.getKey() + ": " + ChatColor.WHITE + e.getValue()));
            if (totemAbuser) {
                lore.add("");
                lore.add(ChatColor.RED + "" + ChatColor.BOLD + ">> AUTO-TOTEM DETECTED <<");
            }

            meta.setLore(lore);
            skull.setItemMeta(meta);
            inv.addItem(skull);
        }

        if (suspects.isEmpty()) {
            ItemStack glass = new ItemStack(Material.GREEN_STAINED_GLASS_PANE);
            ItemMeta m = glass.getItemMeta();
            m.setDisplayName(ChatColor.GREEN + "No suspicious players found!");
            glass.setItemMeta(m);
            inv.setItem(4, glass);
        }

        staff.openInventory(inv);
    }
}
