package dev.rjac.manager;

import dev.rjac.RJ_AC;
import org.bukkit.entity.Player;

import java.util.*;

public class MuteManager {

    private final RJ_AC plugin;
    // uuid -> expiry ms (0 = permanent)
    private final Map<UUID, Long> muted = new HashMap<>();
    private final Map<UUID, String> muteReasons = new HashMap<>();

    public MuteManager(RJ_AC plugin) { this.plugin = plugin; }

    public void mute(Player player, String duration, String reason) {
        long expiry = 0;
        Date d = plugin.getPunishmentManager().parseDuration(duration);
        if (d != null) expiry = d.getTime();
        muted.put(player.getUniqueId(), expiry);
        muteReasons.put(player.getUniqueId(), reason);
        player.sendMessage(plugin.tag() + RJ_AC.color(
            plugin.getConfig().getString("punishments.mute-message","&cYou are muted. Reason: &f{reason}")
                .replace("{reason}", reason)));
        plugin.getLogger().info("[MUTE] " + player.getName() + " | " + reason + " | " + duration);
    }

    public void unmute(UUID uuid) {
        muted.remove(uuid);
        muteReasons.remove(uuid);
    }

    public boolean isMuted(Player player) {
        Long expiry = muted.get(player.getUniqueId());
        if (expiry == null) return false;
        if (expiry == 0) return true;
        if (System.currentTimeMillis() > expiry) { unmute(player.getUniqueId()); return false; }
        return true;
    }

    public String getReason(UUID uuid) { return muteReasons.getOrDefault(uuid, "No reason"); }
}
