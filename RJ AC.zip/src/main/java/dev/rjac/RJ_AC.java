package dev.rjac;

import dev.rjac.data.PlayerDataManager;
import dev.rjac.managers.ViolationManager;
import dev.rjac.packet.PacketHandler;
import org.bukkit.plugin.java.JavaPlugin;

public class RJ_AC extends JavaPlugin {

    private static RJ_AC instance;

    private PlayerDataManager playerDataManager;
    private ViolationManager violationManager;
    private PacketHandler packetHandler;

    @Override
    public void onEnable() {
        instance = this;

        // Save default config on first run
        saveDefaultConfig();

        // Create managers BEFORE anything that uses them
        this.playerDataManager = new PlayerDataManager();
        this.violationManager = new ViolationManager(this);

        // Register ProtocolLib listener
        this.packetHandler = new PacketHandler(this);
        try {
            this.packetHandler.register();
        } catch (Throwable t) {
            getLogger().severe("[RJ_AC] Failed to register packet listener: " + t.getMessage());
            getLogger().severe("[RJ_AC] Is ProtocolLib installed? Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getLogger().info("[RJ_AC] Enabled. Anti-cheat active.");
    }

    @Override
    public void onDisable() {
        if (packetHandler != null) {
            try {
                packetHandler.unregister();
            } catch (Throwable ignored) {}
        }
        getLogger().info("[RJ_AC] Disabled.");
    }

    // ── Public accessors used by other classes ────────────────────

    public PlayerDataManager getPlayerDataManager() {
        return this.playerDataManager;
    }

    public ViolationManager getViolationManager() {
        return this.violationManager;
    }

    public static RJ_AC getInstance() {
        return instance;
    }
}